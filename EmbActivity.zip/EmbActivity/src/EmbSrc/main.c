#include<avr/io.h>
#include<util/delay.h>



int main(void)
{
    uint16_t temp;
    INITADC();

    // Insert code
   void setPorts();
    while(1)
    {
    temp = ReadADC(0b00000101);
    _delay_ms(200);
        if(!(PIND&(1<<PD1))&&(!(PINC&(1<<PC6))))
        {
      PORTD|=(1<<PD2);
      _delay_ms(250);
        }
        else
        {
            PORTD&=(~(1<<PD2));
            _delay_ms(250);
        }
    }
    ;
    return 0;
}
