#ifndef MAIN_H_INCLUDED
#define MAIN_H_INCLUDED

setPorts();
INITADC();
ReadADC();


#endif // MAIN_H_INCLUDED
