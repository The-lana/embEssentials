# Essentials of Embedded C Activity

## LED Actuator

### In Action

|ON|OFF|
|:--:|:--:|
|![ON](simulation/ON.png)|![OFF](simulation/OFF.png) [1-OFF](simulation/1OFF.png) [2-OFF](simulation/2OFF.png)|

#### CI and Code Quality

