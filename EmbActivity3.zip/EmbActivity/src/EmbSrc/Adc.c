#include<avr/io.h>

void INITADC()
{
    ADMUX=(1<<REFS0);   //set Aref=Vcc;
    ADCSRA = (1<<ADEN) | (7<<ADPS0);
}

uint16_t ReadADC(uint8_t ch)
{
    //select ADC channel ch to be 0-7
    ADMUX &= 0xf8;
    ch = ch & 0b00000101;
    ADMUX |= ch;
    //start single conversion
    ADCSRA|=(1<<ADSC);
    //wait for conversion to complete
    while(!(ADCSRA&(1<<ADIF)));
    //clear ADIF by writing one to it
    ADCSRA |= (1<<ADIF);
    return ADC;
}
