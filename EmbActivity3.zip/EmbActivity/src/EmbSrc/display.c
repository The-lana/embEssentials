#include "main.h"
#include <avr/io.h>

void display(uint16_t value)
{
    if(value == 20)
    {
        PORTB|=(1<<PB2) ;
        PORTB &= ~((1<<PB1)| (1<<PB3)| (1<<PB4));
        PORTC &= ~((1<<PC0) | (1<<PC1) | (1<<PC2) | (1<<PC3));
    }
    if (value == 25)
    {
        PORTB|=(1<<PB2) ;
        PORTB &= ~((1<<PB1)| (1<<PB3)| (1<<PB4));
        PORTC |= ((1<<PC0) | (1<<PC2));
        PORTC &= ~((1<<PC1) | (1<<PC3));
    }
    if(value == 29)
    {
        PORTB|=(1<<PB2) ;
        PORTB &= ~((1<<PB1)| (1<<PB3)| (1<<PB4));
        PORTC |= ((1<<PC0)| (1<<PC3));
        PORTC &= ~((1<<PC1) | (1<<PC2));
    }
    if(value == 33)
    {
        PORTB|=((1<<PB1)| (1<<PB2));
        PORTB &= ~((1<<PB3)| (1<<PB4));
        PORTC |= ((1<<PC0) | (1<<PC1));
        PORTC &= ~((1<<PC2) | (1<<PC3));
    }
}
