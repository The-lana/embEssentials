#include<avr/io.h>
#include<util/delay.h>



int main(void)
{
    uint16_t temp;
    INITADC();
    uint16_t value = 0;
    // Insert code
   void setPorts();
    while(1)
    {
    temp = ReadADC(0b00000101);
    _delay_ms(200);
        if(!(PIND&(1<<PD1))&&(!(PINC&(1<<PC6))))
        {
      PORTD|=(1<<PD2);
      _delay_ms(250);
        }
        else
        {
            PORTD&=(~(1<<PD2));
            _delay_ms(250);
        }
    if(temp<200)
       value = 20;
    else if(temp>200 && temp < 500)
        value = 25;
    else if(temp>500 && temp < 700)
        value = 29;
    else if(temp > 700 && temp<1024)
        value = 33;
    display(value);
    }
    ;
    return 0;
}
//get values of adch and adcl convert the 16 bit binary into decimal temp range using table
//send to 7 segment display using a file to set each pin
