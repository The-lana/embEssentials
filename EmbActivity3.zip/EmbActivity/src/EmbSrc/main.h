#ifndef MAIN_H_INCLUDED
#define MAIN_H_INCLUDED

void setPorts();
void INITADC();
 ReadADC();
void display(uint16_t);


#endif // MAIN_H_INCLUDED
