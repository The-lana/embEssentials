#include<avr/io.h>

void setPorts()
{
    
}
